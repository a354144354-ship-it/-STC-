#include "stm32f10x.h"                  // Device header

#define BUFFER_SIZE 64                   // ???????(???2??)
#define BUFFER_MASK (BUFFER_SIZE - 1)    // ??????

uint16_t AD_Value[BUFFER_SIZE];          // ?????
volatile uint32_t writeIndex = 0;        // ???
volatile uint32_t readIndex = 0;         // ???

/**
  * @brief  ADC???(??DMA????)
  */
void AD_Init(void)
{
    /* ???? */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);    // ??ADC1??
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   // ??GPIOA??
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);      // ??DMA1??
    
    /* ??ADC?? */
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);                       // ??6?, ADCCLK = 72MHz/6 = 12MHz
    
    /* GPIO??? */
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* ??ADC???? */
    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_55Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 2, ADC_SampleTime_55Cycles5);
    
    /* ADC??? */
    ADC_InitTypeDef ADC_InitStructure;
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
    ADC_InitStructure.ADC_NbrOfChannel = 2;
    ADC_Init(ADC1, &ADC_InitStructure);
    
    /* DMA??? - ??????????? */
    DMA_InitTypeDef DMA_InitStructure;
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)AD_Value;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = BUFFER_SIZE;          // ?????
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;          // ????
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    
    /* DMA???????? */
    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
    
    /* ??NVIC */
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* ??DMA?ADC */
    DMA_Cmd(DMA1_Channel1, ENABLE);
    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);
    
    /* ADC?? */
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1) == SET);
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1) == SET);
    
    /* ??ADC?? */
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

/**
  * @brief  DMA1??1??????
  * @note   ???????????????
  */
void DMA1_Channel1_IRQHandler(void)
{
    if (DMA_GetITStatus(DMA1_IT_TC1))
    {
        // ??????:????????0
        writeIndex = 0;
        DMA_ClearITPendingBit(DMA1_IT_TC1);
    }
    
    if (DMA_GetITStatus(DMA1_IT_HT1))
    {
        // ?????:??????????
        writeIndex = BUFFER_SIZE / 2;
        DMA_ClearITPendingBit(DMA1_IT_HT1);
    }
}

/**
  * @brief  ??????????????
  * @param  channel: ??? (2 ? 3)
  * @retval ADC?
  */


uint16_t AD_GetLatestValue(uint8_t channel)
{
    uint32_t currentWrite =  writeIndex; // ????!
    uint32_t index;
    uint16_t value = 0;
    
    if (currentWrite >= 2) {
        index = (currentWrite - 2) & BUFFER_MASK;
        if (channel == 2) {
            value = AD_Value[index];
        } else {
            value = AD_Value[index + 1];
        }
    
    }
    return value;
}


/**
  * @brief  ???????ADC?(??????)
  * @param  index: ????? (0 ~ BUFFER_SIZE-1)
  * @retval ADC?
  */
uint16_t AD_GetValueByIndex(uint32_t index)
{
    if (index < BUFFER_SIZE) {
        return AD_Value[index];
    }
    return 0;
}

/**
  * @brief  ??????????
  * @retval ????
  */
uint32_t AD_GetDataCount(void)
{
    // DMA???? = ???(???)
    return writeIndex;
}