/*********************************************************************
 * STM32F10x 下位机 main.c —— 适配 HC04Controller App（V3 协议）
 *
 * 修复说明：
 *  1) 下行解析改为「p[0] 判类型 + atoi 取数」，兼容 App 发送的
 *     @B:xx / @F:xx / @M:0 / @A:0|1 / @STATUS（带 @ 包头、可剥除）
 *  2) 原 strcmp(&Serial_RxPacket[0],"F") 是全串比较，永远不成立，
 *     导致 F/B 指令收不到，已修正。
 *  3) 原 if(strcmp(...A:0)||strcmp(...A:1)==0) 逻辑恒真，已修正。
 *  4) 新增 @STATUS 响应：App 连接后请求一次，下位机全量上报。
 *  5) 主循环加短延时，避免高频刷屏挤占蓝牙带宽。
 *
 * 依赖 Serial.c：Serial_RxPacket 需缓存一整行（含 @ 包头），
 * 收到 '\n' 时置 Serial_RxFlag=1。若你的 Serial.c 已剥掉 '@'，
 * 本代码也能兼容（p[0]!='@' 时直接按类型字符判断）。
 *********************************************************************/
#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "Key.h"
#include "AD.h"
#include "LED.h"
#include "DD.h"
#include "Serial.h"
#include "string.h"
#include "stdio.h"

uint8_t Key;            // 接收按键键码
uint8_t MotorSpeed = 0; // 电机速度变量
uint8_t LEDSpeed = 0;   // LED 亮度变量
uint8_t Modeflag = 0;   // 0=手动  1=自动
uint16_t ADD_Value[2];

/* ---------- 全量状态上报（配合 App 显示区） ---------- */
void Send_AllStatus(void)
{
    Serial_Printf("@T:%d\n", 4096 * 12 / ADD_Value[0]);   // 温度
    Serial_Printf("@L:%d\n", 4096 * 3 / ADD_Value[1]);    // 光照强度
    Serial_Printf("@B:%d\n", LEDSpeed);                   // 当前灯光亮度
    Serial_Printf("@F:%d\n", MotorSpeed);                 // 当前风扇转速
    Serial_Printf("@M:%d\n", Modeflag ? 1 : 2);           // 1=自动 2=手动
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == Bit_RESET)
        Serial_Printf("@A:1\n");                          // 报警触发
    else
        Serial_Printf("@A:0\n");                          // 报警正常
}

int main(void)
{
    /* 模块初始化 */
    OLED_Init();      // OLED 初始化
    Motor_Init();     // 直流电机初始化
    Key_Init();       // 按键初始化
    AD_Init();
    DD_Init();
    Serial_Init();

    /* 显示静态字符串 */
    OLED_ShowString(1, 1, "Mot:");
    OLED_ShowString(1, 8, "LED:");
    OLED_ShowString(3, 1, "Tem"); OLED_ShowString(3, 7, "C");
    OLED_ShowString(4, 1, "Lig");
    OLED_ShowString(2, 1, "Buz");
    OLED_ShowString(3, 9, "Mode");

    while (1)
    {
        ADD_Value[0] = AD_GetLatestValue(2);
        ADD_Value[1] = AD_GetLatestValue(3);

        /* OLED 本地显示 */
        OLED_ShowNum(3, 5, 4096 * 12 / ADD_Value[0], 2);
        OLED_ShowNum(4, 5, 4096 * 3 / ADD_Value[1], 2);
        OLED_ShowNum(1, 5, MotorSpeed, 3);
        OLED_ShowNum(1, 12, LEDSpeed, 3);

        /* ================= 下行解析（App -> 单片机） ================= */
        if (Serial_RxFlag == 1)
        {
            char *p = Serial_RxPacket;
            if (p[0] == '@') p++;            // 剥掉可选 @ 包头
            int val = atoi(p + 2);           // "B:80" 取 80

            switch (p[0])
            {
                case 'F':                    // 设置风扇转速（仅手动模式生效）
                    if (Modeflag == 0) {
                        MotorSpeed = val; if (MotorSpeed > 100) MotorSpeed = 100;
                        Motor_SetSpeed(MotorSpeed);
                    }
                    break;
                case 'B':                    // 设置灯光亮度（仅手动模式生效）
                    if (Modeflag == 0) {
                        LEDSpeed = val; if (LEDSpeed > 100) LEDSpeed = 100;
                        LED_SetSpeed(LEDSpeed);
                    }
                    break;
                case 'M':                    // 模式指令：0=切换 1=自动 2=手动
                    if (p[1] == '0') {       // @M:0  -> 切换模式
                        Modeflag = !Modeflag;
                    } else if (p[1] == '1') { // @M:1 -> 直接设为自动
                        Modeflag = 1;
                    } else if (p[1] == '2') { // @M:2 -> 直接设为手动
                        Modeflag = 0;
                    }
                    break;
                case 'A':                    // 报警指令：@A:1 触发 @A:0 复位
                    if (val == 1) DD_turn();
                    break;
                case 'S':                    // @STATUS -> 全量上报
                    Send_AllStatus();
                    break;
                default:
                    break;
            }
            Serial_RxFlag = 0;
        }

        /* ================= 按键输入 ================= */
        Key = Key_GetNum();
        if (Key == 1) { MotorSpeed += 20; if (MotorSpeed > 100) MotorSpeed = 0; }
        if (Key == 2) { LEDSpeed += 20;   if (LEDSpeed > 100) LEDSpeed = 0; }
        if (Key == 3) { DD_turn(); }

        /* ================= 自动模式（Modeflag==1） ================= */
        if (Modeflag != 0)
        {
            if (4096 * 3 / ADD_Value[1] > 8)        LEDSpeed = 0;
            else if (4096 * 3 / ADD_Value[1] > 4)   LEDSpeed = 50;
            else                                    LEDSpeed = 100;

            if (4096 * 12 / ADD_Value[0] < 26)      MotorSpeed = 0;
            else if (4096 * 12 / ADD_Value[0] < 30) MotorSpeed = 30;
            else { MotorSpeed = 60; DD_turn(); }

            Motor_SetSpeed(MotorSpeed);
            LED_SetSpeed(LEDSpeed);
            Serial_Printf("@M:1\n");                 // 上报：自动
            OLED_ShowString(4, 9, "auto");
        }
        /* ================= 手动模式（Modeflag==0） ================= */
        else
        {
            Motor_SetSpeed(MotorSpeed);
            LED_SetSpeed(LEDSpeed);
            Serial_Printf("@M:2\n");                 // 上报：手动
            OLED_ShowString(4, 9, "hand");
        }

        /* 报警状态 OLED + 上报 */
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == Bit_RESET) {
            OLED_ShowString(2, 5, "run   ");
            Serial_Printf("@A:1\n");
        } else {
            OLED_ShowString(2, 5, "notrun");
            Serial_Printf("@A:0\n");
        }

        Delay_ms(20);   // 降频：避免高频刷屏挤占蓝牙带宽（可调）
    }
}
