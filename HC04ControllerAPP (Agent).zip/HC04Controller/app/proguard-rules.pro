# Add project specific ProGuard rules here.
-keep class com.example.hc04controller.** { *; }
