package com.example.hc04controller;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.hc04controller.bluetooth.BluetoothSerialManager;
import com.example.hc04controller.logic.DeviceLogic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * HC-04 蓝牙控制器 —— 主界面
 *
 * 界面分为三部分：
 *   1) 蓝牙连接区（设备选择 / 扫描 / 波特率 / 自动连接 / 状态 / 调试发送）
 *   2) 设备控制区（灯光亮度、风扇转速、模式切换、报警器 四个按钮）
 *   3) 实时数据区（温度、亮度、模式类别、报警状态 四个显示面板）
 *
 * 所有“按钮发什么指令”“收到数据怎么解析”的逻辑都在
 * {@link com.example.hc04controller.logic.DeviceLogic} 中，改那里即可。
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQ_PERMISSION = 1001;
    private static final String PREFS = "hc04_prefs";
    private static final String KEY_LAST_MAC = "last_mac";

    // ---------------- 连接区 ----------------
    private Spinner deviceSpinner;
    private Spinner baudSpinner;
    private com.google.android.material.materialswitch.MaterialSwitch autoConnectSwitch;
    private com.google.android.material.button.MaterialButton scanButton;
    private com.google.android.material.button.MaterialButton connectButton;
    private View statusDot;
    private TextView statusText;
    private TextView headerStatus;

    // ---------------- 调试发送 ----------------
    private EditText testEditText;
    private com.google.android.material.button.MaterialButton testSendButton;

    // ---------------- 控制区 ----------------
    private SeekBar brightnessSeekBar;
    private SeekBar fanSeekBar;
    private TextView brightnessValueText;
    private TextView fanValueText;
    private TextView modeValueText;
    private TextView alarmStateText;
    private com.google.android.material.button.MaterialButton sendBrightnessButton;
    private com.google.android.material.button.MaterialButton sendFanButton;
    private com.google.android.material.button.MaterialButton modeButton;
    private com.google.android.material.button.MaterialButton alarmButton;

    // ---------------- 显示区 ----------------
    private TextView tempDisplayText;
    private TextView brightDisplayText;
    private TextView fanDisplayText;
    private TextView lightDisplayText;
    private TextView modeDisplayText;
    private TextView alarmDisplayText;
    private View alarmStateDot;

    // ---------------- 状态与数据 ----------------
    private BluetoothSerialManager bt;
    private final List<BluetoothDevice> deviceList = new ArrayList<>();
    private ArrayAdapter<String> deviceAdapter;
    private boolean receiverRegistered = false;

    /** 页面是否已销毁：蓝牙子线程回调在主线程执行时，若页面已销毁则直接忽略，避免空指针 */
    private volatile boolean destroyed = false;

    private boolean alarmOn = false;  // 当前报警开关
    private int lastBrightness = 50;  // 亮度滑条当前值（仅发送用）
    private int lastFan = 50;         // 风扇滑条当前值（仅发送用）

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        destroyed = false;
        installCrashLogger();
        setContentView(R.layout.activity_main);

        bindViews();
        setupSpinners();
        setupListeners();

        bt = new BluetoothSerialManager(btListener);

        if (hasBluetoothPermissions()) {
            onBluetoothReady();
        } else {
            requestBluetoothPermissions();
        }
    }

    // ==================================================================
    //  UI 绑定
    // ==================================================================
    private void bindViews() {
        headerStatus = findViewById(R.id.headerStatus);

        deviceSpinner = findViewById(R.id.deviceSpinner);
        baudSpinner = findViewById(R.id.baudSpinner);
        autoConnectSwitch = findViewById(R.id.autoConnectSwitch);
        scanButton = findViewById(R.id.scanButton);
        connectButton = findViewById(R.id.connectButton);
        statusDot = findViewById(R.id.statusDot);
        statusText = findViewById(R.id.statusText);

        testEditText = findViewById(R.id.testEditText);
        testSendButton = findViewById(R.id.testSendButton);

        brightnessSeekBar = findViewById(R.id.brightnessSeekBar);
        fanSeekBar = findViewById(R.id.fanSeekBar);
        brightnessValueText = findViewById(R.id.brightnessValueText);
        fanValueText = findViewById(R.id.fanValueText);
        modeValueText = findViewById(R.id.modeValueText);
        alarmStateText = findViewById(R.id.alarmStateText);
        sendBrightnessButton = findViewById(R.id.sendBrightnessButton);
        sendFanButton = findViewById(R.id.sendFanButton);
        modeButton = findViewById(R.id.modeButton);
        alarmButton = findViewById(R.id.alarmButton);

        tempDisplayText = findViewById(R.id.tempDisplayText);
        brightDisplayText = findViewById(R.id.brightDisplayText);
        fanDisplayText = findViewById(R.id.fanDisplayText);
        lightDisplayText = findViewById(R.id.lightDisplayText);
        modeDisplayText = findViewById(R.id.modeDisplayText);
        alarmDisplayText = findViewById(R.id.alarmDisplayText);
        alarmStateDot = findViewById(R.id.alarmStateDot);
    }

    private void setupSpinners() {
        // 设备下拉框
        deviceAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new ArrayList<>());
        deviceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deviceSpinner.setAdapter(deviceAdapter);

        // 波特率下拉框（HC 模块波特率由模块 AT 指令决定，此处仅显示记录）
        String[] bauds = new String[DeviceLogic.BAUD_OPTIONS.length];
        for (int i = 0; i < bauds.length; i++) {
            bauds[i] = DeviceLogic.BAUD_OPTIONS[i] + " bps";
        }
        ArrayAdapter<String> baudAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, bauds);
        baudAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        baudSpinner.setAdapter(baudAdapter);
    }

    // ==================================================================
    //  控件监听 —— 每个按钮都调用 DeviceLogic 生成指令
    // ==================================================================
    private void setupListeners() {
        // ---- 扫描设备 ----
        scanButton.setOnClickListener(v -> startScan());

        // ---- 连接 / 断开 ----
        connectButton.setOnClickListener(v -> {
            if (bt != null && bt.isConnected()) {
                bt.disconnect();
            } else {
                connectSelected();
            }
        });

        // ---- 调试发送 ----
        testSendButton.setOnClickListener(v -> {
            String text = testEditText.getText().toString().trim();
            if (text.isEmpty()) {
                Toast.makeText(this, "请输入要发送的指令", Toast.LENGTH_SHORT).show();
                return;
            }
            sendCommand(text.getBytes(), "调试指令");
        });

        // ---- 滑动条触摸保护 ----
        // 页面在 ScrollView 中可滚动时，ScrollView 会拦截滑动条的横向拖动手势，
        // 导致"拖不动"。按下时禁止父容器拦截，抬起/取消时恢复，保证滑条随时可拖。
        View.OnTouchListener seekBarTouchGuard = new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false; // 不消费事件，交给 SeekBar 自身处理
            }
        };
        brightnessSeekBar.setOnTouchListener(seekBarTouchGuard);
        fanSeekBar.setOnTouchListener(seekBarTouchGuard);

        // ---- 灯光亮度（滑动条 = 纯发送输入，与实时显示完全解耦） ----
        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    lastBrightness = progress;
                    brightnessValueText.setText(progress + "%");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        sendBrightnessButton.setOnClickListener(v ->
                sendCommand(DeviceLogic.buildBrightnessCommand(lastBrightness), "亮度指令"));

        // ---- 风扇转速（滑动条 = 纯发送输入，与实时显示完全解耦） ----
        fanSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    lastFan = progress;
                    fanValueText.setText(progress + "%");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        sendFanButton.setOnClickListener(v ->
                sendCommand(DeviceLogic.buildFanCommand(lastFan), "转速指令"));

        // ---- 模式切换（仅发送"切换"指令，当前模式由单片机上报 @M:x 决定） ----
        modeButton.setOnClickListener(v ->
                sendCommand(DeviceLogic.buildModeToggleCommand(), "模式切换"));

        // ---- 报警器开关（切换） ----
        alarmButton.setOnClickListener(v -> {
            alarmOn = !alarmOn;
            updateAlarmUi();
            sendCommand(DeviceLogic.buildAlarmCommand(alarmOn), "报警器");
        });
    }

    // ==================================================================
    //  蓝牙：权限 / 扫描 / 连接 / 收发
    // ==================================================================
    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN}, REQ_PERMISSION);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSION) {
            if (hasBluetoothPermissions()) {
                onBluetoothReady();
            } else {
                Toast.makeText(this, "需要蓝牙权限才能连接设备", Toast.LENGTH_LONG).show();
            }
        }
    }

    /** 权限就绪后：加载已配对设备 + 自动连接 */
    @SuppressLint("MissingPermission")
    private void onBluetoothReady() {
        BluetoothAdapter adapter = bt.getAdapter();
        if (adapter == null) {
            Toast.makeText(this, "当前设备不支持蓝牙", Toast.LENGTH_LONG).show();
            return;
        }
        if (adapter.getState() != BluetoothAdapter.STATE_ON) {
            Toast.makeText(this, "请先打开蓝牙", Toast.LENGTH_LONG).show();
        }
        registerDiscoveryReceiver();
        loadPairedDevices();

        // 开机自动连接上次设备
        if (autoConnectSwitch.isChecked()) {
            String lastMac = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LAST_MAC, null);
            if (lastMac != null) {
                try {
                    BluetoothDevice last = adapter.getRemoteDevice(lastMac);
                    if (last != null && last.getBondState() == BluetoothDevice.BOND_BONDED) {
                        bt.connect(last);
                    }
                } catch (IllegalArgumentException | SecurityException e) {
                    // 上次保存的地址失效或权限被收回时，忽略自动连接
                }
            }
        }
    }

    private void registerDiscoveryReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(discoveryReceiver, filter);
        receiverRegistered = true;
    }

    private final BroadcastReceiver discoveryReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) addDevice(device);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                scanButton.setEnabled(true);
                Toast.makeText(context, "扫描完成", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @SuppressLint("MissingPermission")
    private void loadPairedDevices() {
        deviceList.clear();
        BluetoothAdapter adapter = bt.getAdapter();
        if (adapter == null) return;
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded != null) {
            deviceList.addAll(bonded);
        }
        refreshDeviceAdapter();
        // 若之前连接过，把下拉框指到该设备
        String lastMac = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LAST_MAC, null);
        if (lastMac != null) {
            for (int i = 0; i < deviceList.size(); i++) {
                if (lastMac.equals(deviceList.get(i).getAddress())) {
                    deviceSpinner.setSelection(i);
                    break;
                }
            }
        }
    }

    private void refreshDeviceAdapter() {
        List<String> names = new ArrayList<>();
        for (BluetoothDevice d : deviceList) {
            String name = d.getName();
            if (name == null || name.isEmpty()) name = "未知设备";
            names.add(name + "  (" + d.getAddress() + ")");
        }
        deviceAdapter.clear();
        deviceAdapter.addAll(names);
        deviceAdapter.notifyDataSetChanged();
    }

    @SuppressLint("MissingPermission")
    private void startScan() {
        BluetoothAdapter adapter = bt.getAdapter();
        if (adapter == null) {
            Toast.makeText(this, "当前设备不支持蓝牙", Toast.LENGTH_LONG).show();
            return;
        }
        if (adapter.getState() != BluetoothAdapter.STATE_ON) {
            Toast.makeText(this, "请先打开蓝牙", Toast.LENGTH_LONG).show();
            return;
        }
        // 把已配对设备先加入列表，再开始发现新设备
        loadPairedDevices();
        scanButton.setEnabled(false);
        Toast.makeText(this, "正在扫描…", Toast.LENGTH_SHORT).show();
        if (adapter.isDiscovering()) adapter.cancelDiscovery();
        adapter.startDiscovery();
    }

    @SuppressLint("MissingPermission")
    private void addDevice(BluetoothDevice device) {
        for (BluetoothDevice d : deviceList) {
            if (d.getAddress().equals(device.getAddress())) return;
        }
        deviceList.add(device);
        refreshDeviceAdapter();
    }

    private void connectSelected() {
        int pos = deviceSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= deviceList.size()) {
            Toast.makeText(this, "请先选择或扫描蓝牙设备", Toast.LENGTH_LONG).show();
            return;
        }
        if (bt == null) return;
        bt.connect(deviceList.get(pos));
    }

    /** 统一发送入口：未连接时给出提示 */
    private void sendCommand(byte[] data, String what) {
        if (bt == null || !bt.isConnected()) {
            Toast.makeText(this, "请先连接蓝牙", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean ok = bt.send(data);
        if (!ok) {
            Toast.makeText(this, what + "发送失败", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================================================================
    //  蓝牙回调
    // ==================================================================
    private final BluetoothSerialManager.Listener btListener = new BluetoothSerialManager.Listener() {
        @SuppressLint("MissingPermission")
        @Override
        public void onConnected(BluetoothDevice device) {
            if (destroyed) return;
            updateConnectionUi(true, "已连接：" + (device.getName() == null ? device.getAddress() : device.getName()));
            Toast.makeText(MainActivity.this, "蓝牙已连接", Toast.LENGTH_SHORT).show();
            // 记住该设备，下次自动连接
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit().putString(KEY_LAST_MAC, device.getAddress()).apply();
            // 可选：连接成功后向设备请求一次状态（逻辑见 DeviceLogic）
            if (bt != null) bt.send(DeviceLogic.buildOnConnectCommand());
        }

        @Override
        public void onDisconnected() {
            if (destroyed) return;
            updateConnectionUi(false, getString(R.string.status_disconnected));
            Toast.makeText(MainActivity.this, "蓝牙已断开", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onConnectionFailed(String reason) {
            if (destroyed) return;
            updateConnectionUi(false, "连接失败");
            Toast.makeText(MainActivity.this, "连接失败：" + reason, Toast.LENGTH_LONG).show();
        }

        @Override
        public void onDataReceived(String line) {
            if (destroyed) return;
            // ======= 收到一行数据 → 交给 DeviceLogic 解析并刷新界面 =======
            handleReceivedData(line);
        }
    };

    // ==================================================================
    //  数据显示 —— 解析结果刷新四个面板
    // ==================================================================
    // ==================================================================
    // 上报刷新：合并节流
    // 蓝牙上报可能极高频（如 10ms 一条），若每帧都 setText/setProgress
    // 会刷爆主线程消息队列，导致滑动条"拖不动"。
    // 这里只缓存最新一帧数据，每 UI_REFRESH_INTERVAL_MS 才真正刷新一次界面。
    // ==================================================================
    private static final long UI_REFRESH_INTERVAL_MS = 100;
    private final Handler uiRefreshHandler = new Handler(Looper.getMainLooper());
    private boolean uiRefreshScheduled = false;
    private DeviceLogic.ParsedData pendingData = null;

    private void handleReceivedData(String line) {
        final DeviceLogic.ParsedData data = DeviceLogic.parseReceivedData(line);
        runOnUiThread(() -> scheduleUiRefresh(data));
    }

    /** 缓存最新一帧并安排一次合并刷新（在主线程调用） */
    private void scheduleUiRefresh(DeviceLogic.ParsedData data) {
        pendingData = data;
        if (uiRefreshScheduled) return;      // 已有待刷新的帧，仅更新最新数据
        uiRefreshScheduled = true;
        uiRefreshHandler.postDelayed(this::applyPendingData, UI_REFRESH_INTERVAL_MS);
    }

    /** 用最新一帧数据刷新界面（合并刷新，不丢事件，最多延迟一个刷新间隔） */
    private void applyPendingData() {
        uiRefreshScheduled = false;
        DeviceLogic.ParsedData data = pendingData;
        pendingData = null;
        if (data == null) return;
        // 温度显示
        if (data.hasTemperature) {
            tempDisplayText.setText(String.format(Locale.CHINA, "%.1f", data.temperature));
        }
        // 当前灯光亮度（完全由单片机上报驱动，与控制区滑动条解耦）
        if (data.hasBrightness) {
            brightDisplayText.setText(String.valueOf(data.brightness));
        }
        // 当前风扇转速（完全由单片机上报驱动，与控制区滑动条解耦）
        if (data.hasFanSpeed) {
            fanDisplayText.setText(String.valueOf(data.fanSpeed));
        }
        // 光照强度显示
        if (data.hasLight) {
            lightDisplayText.setText(String.valueOf(data.light));
        }
        // 模式类别显示（由单片机上报 @M:x 决定，App 不本地维护）
        if (data.hasMode) {
            modeValueText.setText(DeviceLogic.modeName(data.mode));
            modeDisplayText.setText(DeviceLogic.modeName(data.mode));
        }
        // 报警状态显示
        if (data.hasAlarm) {
            alarmOn = data.alarm == 1;
            updateAlarmUi();
        }
    }

    /** 根据报警开关状态刷新相关控件颜色与文字 */
    private void updateAlarmUi() {
        if (alarmOn) {
            alarmButton.setText(R.string.btn_alarm_on);
            alarmButton.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_red)));
            alarmStateText.setText("开启");
            alarmStateText.setTextColor(ContextCompat.getColor(this, R.color.status_red));
            alarmDisplayText.setText("触发");
            alarmDisplayText.setTextColor(ContextCompat.getColor(this, R.color.status_red));
            alarmStateDot.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_red)));
        } else {
            alarmButton.setText(R.string.btn_alarm_off);
            alarmButton.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.btn_blue_bg)));
            alarmStateText.setText("关闭");
            alarmStateText.setTextColor(ContextCompat.getColor(this, R.color.status_gray));
            alarmDisplayText.setText("正常");
            alarmDisplayText.setTextColor(ContextCompat.getColor(this, R.color.status_green));
            alarmStateDot.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_green)));
        }
    }

    /** 更新顶部与连接区的连接状态显示 */
    private void updateConnectionUi(boolean connected, String text) {
        statusText.setText(text);
        headerStatus.setText(text);
        int dotColor = connected ? ContextCompat.getColor(this, R.color.status_green)
                : ContextCompat.getColor(this, R.color.status_gray);
        statusDot.setBackgroundTintList(ColorStateList.valueOf(dotColor));
        connectButton.setText(connected ? R.string.btn_disconnect : R.string.btn_connect);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        super.onDestroy();
        if (receiverRegistered) {
            try {
                unregisterReceiver(discoveryReceiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
        if (bt != null) {
            bt.disconnect();
        }
    }

    // ==================================================================
    //  崩溃日志捕获：即使再闪退，也能在应用目录找到确切堆栈
    //  路径：/sdcard/Android/data/com.example.hc04controller/files/crash.log
    // ==================================================================
    private void installCrashLogger() {
        try {
            final Thread.UncaughtExceptionHandler def =
                    Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
                try {
                    File dir = getFilesDir();
                    if (dir != null) {
                        File f = new File(dir, "crash.log");
                        StringWriter sw = new StringWriter();
                        throwable.printStackTrace(new PrintWriter(sw));
                        FileOutputStream fos = new FileOutputStream(f, false);
                        fos.write(sw.toString().getBytes("UTF-8"));
                        fos.close();
                    }
                } catch (Exception ignored) {
                }
                android.util.Log.e("HC04Crash", "uncaught", throwable);
                if (def != null) {
                    def.uncaughtException(thread, throwable);
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid());
                }
            });
        } catch (Exception ignored) {
        }
    }
}
