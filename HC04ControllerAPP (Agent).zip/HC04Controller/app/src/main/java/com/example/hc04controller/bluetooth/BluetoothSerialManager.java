package com.example.hc04controller.bluetooth;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

/**
 * 蓝牙串口（SPP）连接管理器。
 * 负责：连接 / 断开 / 接收数据分包 / 发送指令。
 * 使用标准 SPP UUID，适用于 HC-04 / HC-05 等常见蓝牙串口模块。
 * 界面层只需实现 Listener 回调即可，本类不依赖任何 UI。
 */
public class BluetoothSerialManager {

    private static final String TAG = "BluetoothSerial";

    /** 标准蓝牙串口（SPP）服务 UUID，HC-04/HC-05 通用 */
    public static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    /** 回调接口：所有回调都在主线程执行 */
    public interface Listener {
        /** 连接成功 */
        void onConnected(BluetoothDevice device);

        /** 连接断开（主动或异常） */
        void onDisconnected();

        /** 连接失败 */
        void onConnectionFailed(String reason);

        /** 收到一行完整数据（按换行符分包，已去除行尾） */
        void onDataReceived(String line);
    }

    private BluetoothAdapter adapter;
    private Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private BluetoothSocket socket;
    private InputStream inputStream;
    private OutputStream outputStream;

    private Thread connectThread;
    private Thread readThread;

    private volatile boolean connected = false;
    private volatile boolean reading = false;

    public BluetoothSerialManager(Listener listener) {
        this.listener = listener;
        this.adapter = BluetoothAdapter.getDefaultAdapter();
    }

    public boolean isConnected() {
        return connected;
    }

    public BluetoothAdapter getAdapter() {
        return adapter;
    }

    /** 开始连接指定设备（在后台线程进行，不阻塞主线程）。 */
    @SuppressLint("MissingPermission")
    public void connect(BluetoothDevice device) {
        if (device == null) {
            notifyFailed("设备为空");
            return;
        }
        if (connected) {
            Log.w(TAG, "already connected");
            return;
        }
        // 防重复连接：上一次连接还在进行中则忽略
        if (connectThread != null && connectThread.isAlive()) {
            Log.w(TAG, "connect already in progress");
            return;
        }
        final BluetoothDevice target = device;
        connectThread = new Thread(() -> {
            BluetoothSocket tmp = null;
            try {
                tmp = target.createRfcommSocketToServiceRecord(SPP_UUID);
                // 连接前取消发现，可加快连接速度
                if (adapter != null && adapter.isDiscovering()) {
                    adapter.cancelDiscovery();
                }
                tmp.connect();
            } catch (IOException e) {
                Log.e(TAG, "connect failed", e);
                try {
                    // 部分模块需要使用 createRfcommSocket(1) 方式，失败时兜底重试
                    tmp = target.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    tmp.connect();
                } catch (IOException e2) {
                    Log.e(TAG, "fallback connect failed", e2);
                    notifyFailed(e.getMessage());
                    try {
                        if (tmp != null) tmp.close();
                    } catch (IOException ignored) {
                    }
                    return;
                }
            }
            socket = tmp;
            try {
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "get stream failed", e);
                notifyFailed("获取数据流失败");
                closeQuietly();
                return;
            }
            connected = true;
            mainHandler.post(() -> {
                if (listener != null) listener.onConnected(target);
            });
            startReading();
        }, "BT-Connect");
        connectThread.start();
    }

    /** 发送数据（十六进制字节数组）。 */
    public boolean send(byte[] data) {
        if (!connected || outputStream == null || data == null) return false;
        try {
            outputStream.write(data);
            outputStream.flush();
            return true;
        } catch (IOException e) {
            Log.e(TAG, "send failed", e);
            disconnect();
            return false;
        }
    }

    /** 发送文本（自动加 UTF-8 编码）。 */
    public boolean sendText(String text) {
        return send(text.getBytes());
    }

    /** 主动断开连接。 */
    public void disconnect() {
        connected = false;
        reading = false;
        closeQuietly();
        mainHandler.post(() -> {
            if (listener != null) listener.onDisconnected();
        });
    }

    private void closeQuietly() {
        try {
            if (inputStream != null) inputStream.close();
        } catch (IOException ignored) {
        }
        try {
            if (outputStream != null) outputStream.close();
        } catch (IOException ignored) {
        }
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
        inputStream = null;
        outputStream = null;
        socket = null;
    }

    /** 后台接收线程：读字节流，按换行符分包后回调。 */
    private void startReading() {
        reading = true;
        readThread = new Thread(() -> {
            byte[] buf = new byte[1024];
            StringBuilder line = new StringBuilder();
            int n;
            while (reading && inputStream != null) {
                try {
                    n = inputStream.read(buf);
                    if (n <= 0) continue;
                    for (int i = 0; i < n; i++) {
                        char c = (char) (buf[i] & 0xFF);
                        if (c == '\n') {
                            final String out = line.toString().trim();
                            line.setLength(0);
                            if (!out.isEmpty()) {
                                mainHandler.post(() -> {
                                    if (listener != null) listener.onDataReceived(out);
                                });
                            }
                        } else if (c != '\r') {
                            line.append(c);
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "read error, socket closed", e);
                    break;
                } catch (RuntimeException e) {
                    // 个别机型在流关闭时可能抛异常，兜底后退出读取循环
                    Log.e(TAG, "read runtime error", e);
                    break;
                }
            }
            // 读取循环退出：若仍是连接状态，说明是异常断开
            if (connected) {
                connected = false;
                mainHandler.post(() -> {
                    if (listener != null) listener.onDisconnected();
                });
            }
        }, "BT-Read");
        readThread.start();
    }

    private void notifyFailed(final String reason) {
        mainHandler.post(() -> {
            if (listener != null) listener.onConnectionFailed(reason);
        });
    }
}
