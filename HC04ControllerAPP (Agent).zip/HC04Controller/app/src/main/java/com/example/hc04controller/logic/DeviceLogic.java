package com.example.hc04controller.logic;

import java.util.Locale;

/**
 * ============================================================
 *  DeviceLogic —— 【全部自定义逻辑集中在这里】
 * ------------------------------------------------------------
 *  界面（MainActivity）和蓝牙连接（BluetoothSerialManager）
 *  都不需要改动。你只需要改这一个文件，就能自定义：
 *
 *   1) 四个控制按钮发送什么指令（灯光亮度 / 风扇转速 / 模式切换 / 报警器）
 *   2) 四个数据显示界面如何解析收到的数据（温度 / 亮度 / 模式 / 报警状态）
 *   3) 模式名称、指令分隔符、行尾符号等协议细节
 *
 *  默认协议（你可随意修改）：
 *    发送指令为文本行，每条以 '@' 包头：  @B:080<换行>  亮度(三位补零 000~100)
 *                                       @F:060<换行>  风扇(三位补零 000~100)
 *                                       @M:0<换行>    切换模式(仅切换)
 *                                       @A:1<换行>    报警开  @A:0<换行> 报警关
 *    收到数据为文本行，例如：  @T:25.5   @B:070   @L:085   @M:1   @A:0
 *    '@' 为包头，接收方靠它做帧同步、丢弃无效数据。
 * ============================================================
 */
public class DeviceLogic {

    // ==================================================================
    //  一、模式定义（显示用，可自定义）
    //  协议值：1=自动  2=手动
    // ==================================================================
    /** 模式协议值：自动 */
    public static final int MODE_AUTO = 1;
    /** 模式协议值：手动 */
    public static final int MODE_MANUAL = 2;
    /** 默认模式（打开 App 时的初始模式） */
    public static final int MODE_DEFAULT = MODE_AUTO;

    /** 由模式协议值得到显示名称；未知值兜底显示“未知”。 */
    public static String modeName(int mode) {
        if (mode == MODE_AUTO) return "自动";
        if (mode == MODE_MANUAL) return "手动";
        return "未知";
    }

    // ==================================================================
    //  二、串口参数
    //  HC-04/HC-05 的波特率是在模块上通过 AT 指令配置的，
    //  App 端仅做“显示与记录”，不会真正影响模块波特率。
    //  这里列出常用波特率供界面下拉选择。
    // ==================================================================
    public static final int[] BAUD_OPTIONS = {9600, 19200, 38400, 57600, 115200};

    /** 行尾符号（每条指令/每条数据的结束符），可自定义，如 "\r\n" */
    private static final String LINE_END = "\n";

    /** 包头：每条指令/数据都以 @ 开头，接收方据此做帧同步，可自定义 */
    private static final String PACKET_HEAD = "@";

    /** 数值上下限保护 */
    private static int clamp(int v) {
        if (v < 0) return 0;
        if (v > 100) return 100;
        return v;
    }

    // ==================================================================
    //  三、四个控制按钮 —— 指令生成（你要自定义的部分）
    //  返回值是真正通过蓝牙发送给单片机的字节数组。
    //  你可以改成任意格式：ASCII 文本、十六进制字节、结构体等。
    // ==================================================================

    /**
     * 【按钮1：灯光亮度】生成亮度指令（数值三位补零，方便解析）
     * @param level 亮度 0~100
     */
    public static byte[] buildBrightnessCommand(int level) {
        level = clamp(level);
        // 示例格式：@B:080\n（000~100 恒为三位）
        return (PACKET_HEAD + "B:" + String.format(Locale.US, "%03d", level) + LINE_END).getBytes();
    }

    /**
     * 【按钮2：风扇转速】生成转速指令（数值三位补零，方便解析）
     * @param speed 转速 0~100
     */
    public static byte[] buildFanCommand(int speed) {
        speed = clamp(speed);
        // 示例格式：@F:060\n（000~100 恒为三位）
        return (PACKET_HEAD + "F:" + String.format(Locale.US, "%03d", speed) + LINE_END).getBytes();
    }

    /**
     * 【按钮3：模式切换】生成"切换模式"指令（仅切换，不指定目标模式）。
     * 当前模式由单片机决定并通过 @M:1/@M:2 上报，App 不本地维护。
     * 协议：@M:0 表示"切换"（0 不是合法模式值 1/2，语义不冲突）
     */
    public static byte[] buildModeToggleCommand() {
        // 示例格式：@M:0\n
        return (PACKET_HEAD + "M:0" + LINE_END).getBytes();
    }

    /**
     * 【按钮4：报警器】生成报警开关指令
     * @param on true=开启 / false=关闭
     */
    public static byte[] buildAlarmCommand(boolean on) {
        // 示例格式：@A:1\n / @A:0\n
        return (PACKET_HEAD + (on ? "A:1" : "A:0") + LINE_END).getBytes();
    }

    // ==================================================================
    //  四、四个数据显示界面 —— 数据解析（你要自定义的部分）
    //  蓝牙收到一行数据后，本方法负责把它解析成四个显示值。
    // ==================================================================

    /** 一次解析的结果：哪个字段有效，就刷新哪个显示界面。 */
    public static class ParsedData {
        public boolean hasTemperature;
        public float temperature;   // 温度 ℃

        public boolean hasBrightness;
        public int brightness;      // 亮度 0~100

        public boolean hasFanSpeed;
        public int fanSpeed;        // 风扇转速 0~100

        public boolean hasLight;
        public int light;           // 光照强度 0~100

        public boolean hasMode;
        public int mode;            // 模式协议值 1=自动 2=手动

        public boolean hasAlarm;
        public int alarm;           // 0=正常 1=触发
    }

    /**
     * 解析一行收到的数据。
     * 默认按 "T:xx" "B:xx" "M:x" "A:x" 前缀识别，
     * B/F/L 数值按三位补零（如 @B:070、@L:085）或普通长度（@B:70）均可解析。
     * 可在此处追加你自己的协议（例如 JSON、十六进制、多字节帧）。
     *
     * @param line 已去除行尾符的整行文本
     * @return 解析结果，无匹配字段时返回全 false 的空对象
     */
    public static ParsedData parseReceivedData(String line) {
        ParsedData d = new ParsedData();
        if (line == null) return d;

        String t = line.trim();

        // 兼容可选的 @ 包头：收到 @T:25.5 时先剥掉 @ 再按 T: 解析
        if (t.startsWith(PACKET_HEAD)) {
            t = t.substring(PACKET_HEAD.length()).trim();
        }

        try {
            if (t.startsWith("T:") || t.startsWith("t:")) {
                // 温度
                d.hasTemperature = true;
                d.temperature = Float.parseFloat(t.substring(2).trim());
            } else if (t.startsWith("B:") || t.startsWith("b:")) {
                // 亮度
                d.hasBrightness = true;
                d.brightness = Integer.parseInt(t.substring(2).trim());
            } else if (t.startsWith("F:") || t.startsWith("f:")) {
                // 风扇转速
                d.hasFanSpeed = true;
                d.fanSpeed = Integer.parseInt(t.substring(2).trim());
            } else if (t.startsWith("L:") || t.startsWith("l:")) {
                // 光照强度
                d.hasLight = true;
                d.light = Integer.parseInt(t.substring(2).trim());
            } else if (t.startsWith("M:") || t.startsWith("m:")) {
                // 模式类别
                d.hasMode = true;
                d.mode = Integer.parseInt(t.substring(2).trim());
            } else if (t.startsWith("A:") || t.startsWith("a:")) {
                // 报警状态
                d.hasAlarm = true;
                d.alarm = Integer.parseInt(t.substring(2).trim());
            }
            // ============ 在此追加你自己的协议解析 ============
            // 例如：else if (t.startsWith("H:")) { d.hasTemperature = true;
            //                                        d.temperature = ...; }
            // 或者解析多段数据：按空格/逗号拆分后逐段识别。
        } catch (NumberFormatException e) {
            // 数值格式不对，忽略这一行
        }
        return d;
    }

    // ==================================================================
    //  五、其他可自定义逻辑（可选）
    // ==================================================================

    /** 连接成功后，是否向单片机发送一条“握手/请求状态”指令（可选）。 */
    public static byte[] buildOnConnectCommand() {
        // 示例：请求设备返回一次状态
        return "@STATUS\n".getBytes();
    }
}
